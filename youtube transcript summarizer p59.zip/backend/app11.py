import openai

openai.api_key = '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'

response = openai.Completion.create(
    engine="gpt-3.5-turbo-0125",  # Use the appropriate GPT-3 engine
    prompt="Summarize the following text: [thank you so much for joining night eighteen of my solo moto camping adventure today we are packing to head about 1 5 hours ne of melbourne quite close to the campsite we visited during night four at a place called warburton i would like to acknowledge the traditional custodians of the land on which we meet today the wurundjeri people i would like to pay respect to elders past present and emerging and any aboriginal and torres strait islander people here today taking the small tent with us today i would like to say a massive thank you to quad lock case who have sponsored this video today s adventure quad lock make it possible for me to safely mount my phone to my bike so that i can navigate to each destination safely my favourite setup is the wireless charger so that my phone never goes flat paired with the vibration dampener to protect the camera lenses from any vibrations i have been using quad lock for the past five years travelling thousands of kilometres on and off road and there is no other phone mounting system that i trust more i have placed a link in the description to the mounts i use but they also have a lot more accessories like desk mounts car mounts and even bicycle mounts use code motofeelz at checkout for 10 off everything storewide and navigate to your next destination safely i love camping in the mountains i am so excited for this it was a steep climb but we made it beautiful i have recently uploaded an extended ad free version of night 1 two three exclusive to members only if you would like to become a member click the join button above or below this video and enjoy the uninterrupted extended versions of each night more it is been a while since setting this tent up let us hope i still remember i am going to leave the fly off for now see how the weather goes and i we might sleep under the stars it will be so nice and cosy it is already quite late need to get dinner started the days are already getting noticeably shorter here in australia i cannot believe winter is just around the corner the weather does not look too happy a massive thank you to batts on bike blue hippo moto for supplying the beers for this trip if you would like to purchase a beer or support my next adventure i have a link in the description below every donation will receive a shoutout in my upcoming video cheers this beer is quite refreshing nice and crisp it is going down really well what a view the wind changed nothing like burgers beer and a view so good looks like rain time to get the fly on and all my gear in no sleeping under the stars for us hopefully next time the ground is really hard here it comes big false alarm oh well let us go for an evening explore i have been playing days gone after reading so many comments it is such a good game this camera angle is inspired by the game i love jett he can handle this stuff with no problems what an incredible spot i will be camping here soon i have never ridden off road in the dark i can see more than the camera can though i am still being very cautious sneak peek at that incredible sunset back nice and safe i hope you enjoyed that little venture and it was not too loud i am exhausted i could not sleep with the stars but i will let you sleep with them enjoy and i will see you in the morning good morning it was so windy and rainy last night i just realised i left the matches in the chair out in the rain it was a new packet too usually i have flint steel with me but for some reason i did not pack it lesson learnt so no coffee or hot breakfast for me this morning luckily i have emergency rations tuna rice beans what a beautiful misty morning it is chilly time to pack up and find us some coffee remember to check the link in the description if you need a secure phone mount i have been here once before they have good coffee putting my order in disposing of my waste while i wait finally thank you so much for joining us on our adventure please show your support by liking this video and subscribing to the channel till next time ciao everyone]",
    max_tokens=150  # Set the desired length of the summary
)

summary = response.choices[0].text.strip()
print(summary)

import openai

openai.api_key = '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'

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",  # Use the appropriate chat-based model
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Summarize the following text: [Your text here]"}
    ]
)

summary = response['choices'][0]['message']['content'].strip()
print(summary)
