from flask import Flask, request, jsonify
from flask_cors import CORS
from model.extract_transcript import get_transcript
from model.preprocess import preprocess_transcript

app = Flask(__name__)
CORS(app)

@app.route('/receive_id', methods=['POST'])
def get_summary():
    try:
        data = request.json
        video_id = data['video_id']  # Get video_id from JSON data
        raw_transcript = get_transcript(video_id)
        transcript = preprocess_transcript(raw_transcript)
        summary = "HELLO THIS IS THE SUMMARY YOU SEE FOR EVERY VIDEO, GOOD BYE"

        return jsonify({'transcript': raw_transcript, 'summary': summary})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
