chrome.runtime.onMessage.addListener((message) => {
    const transcriptElement = document.getElementById('transcript');
    
    if (message.transcript) {
        transcriptElement.textContent = message.transcript;
    } else if (message.error) {
        transcriptElement.textContent = `Error: ${message.error}`;
    }
});

document.getElementById('saveSettings').addEventListener('click', () => {
    const fontSizeElement = document.getElementById('fontSize');
    const selectedFontSize = fontSizeElement ? fontSizeElement.value : null;

    if (selectedFontSize) {
        chrome.storage.sync.set({ fontSize: selectedFontSize }, () => {
            // Update status to let the user know options were saved.
            const status = document.getElementById('status');
            status.textContent = 'Options saved.';
            setTimeout(() => { status.textContent = ''; }, 1500);
        });
    }
});

// Restores select box state using the preferences stored in chrome.storage
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.sync.get('fontSize', (items) => {
        const fontSizeElement = document.getElementById('fontSize');
        if (fontSizeElement && items.fontSize) {
            fontSizeElement.value = items.fontSize;
        }
    });
});
