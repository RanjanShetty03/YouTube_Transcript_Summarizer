chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fetchTranscript") {
        const transcriptUrl = 'https://yousumma.onrender.com/receive_id';

        // Create data object with videoId
        const data = {
            video_id: request.videoId
        };

        // Fetch transcript from the server
        fetch(transcriptUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Failed to fetch transcript. Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Transcript data received:', data);
            // Send the transcript back to the content script
            chrome.tabs.sendMessage(sender.tab.id, { transcript: data });
        })
        .catch(error => {
            // Send error message back to the content script
            chrome.tabs.sendMessage(sender.tab.id, { error: error.message });
        });

        return true; // Keep the message channel open for the response
    }
});
