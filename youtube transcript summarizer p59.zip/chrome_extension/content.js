function addButton() {
    const controls = document.querySelector('.ytp-right-controls');
    if (controls) {
        const buttonDiv = document.createElement('div');
        buttonDiv.classList.add('ytp-button', 'transcript-button');
        buttonDiv.style.cssText = 'font-size: 22px; color: white; cursor: pointer;';
        buttonDiv.title = 'Summarize';
        
        buttonDiv.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M14.528 12.52a7.5 7.5 0 1 0-1.408 1.408l3.683 3.682a1 1 0 0 0 1.414-1.414l-3.683-3.683zM1.5 7.5a6 6 0 1 1 12 0 6 6 0 0 1-12 0z"/>
            </svg>
        `;
        
        buttonDiv.addEventListener('click', () => {
            const videoId = new URL(location.href).searchParams.get('v');
            chrome.runtime.sendMessage({ action: "fetchTranscript", videoId: videoId }, (response) => {
                if (response.transcript) {
                    displayTranscript(response.transcript);
                } else {
                    console.error('Error fetching transcript:', response.error);
                }
            });
        });
        controls.appendChild(buttonDiv);
    }
}

function switchTab(container, activeTab) {
    const tabs = container.querySelectorAll('.tab-button');
    const contents = container.querySelectorAll('.tab-content');

    tabs.forEach(tab => tab.classList.remove('active-tab'));
    contents.forEach(content => content.style.display = 'none');

    activeTab.classList.add('active-tab');
    const targetContentId = activeTab.dataset.target;
    const targetContent = document.getElementById(targetContentId);
    if (targetContent) {
        targetContent.style.display = 'block';
    }
}

function displayTranscript(transcriptData) {
    let transcriptContainer = document.getElementById('transcript-container');

    if (!transcriptContainer) {
        transcriptContainer = document.createElement('div');
        transcriptContainer.id = 'transcript-container';
        transcriptContainer.dataset.summary = transcriptData.summary;
        transcriptContainer.dataset.transcript = transcriptData.transcript;

        // Main container styles
        transcriptContainer.style.cssText = `
            position: fixed; bottom: 10px; right: 10px; 
            width: 400px; height: 450px; overflow: hidden; 
            background: aliceblue; border: 1px solid #ccc; 
            border-radius: 15px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
            z-index: 1000; font-family: Poppins, sans-serif;
            padding: 40px 10px 10px 10px; color: #000;
            border: 2px solid ;
        `;

        // Header div
        const header = document.createElement('div');
        header.style.cssText = `
            position: absolute; top: 0; left: 0; width: 100%; 
            height: 30px; padding-bottom: 0px; padding-right:2px; padding-top: 10px; background: #FF0000; 
            border: none; display: flex;
            border-bottom: 2px solid;
        `;

       // Summary tab
                // Summary tab
        const summaryTab = document.createElement('button');
        summaryTab.textContent = 'Summary';
        summaryTab.classList.add('tab-button', 'active-tab');
        summaryTab.dataset.target = 'summary-content';
        summaryTab.onclick = function () {
            switchTab(transcriptContainer, summaryTab);
            summaryTab.style.backgroundColor = '#141010'; // Change background color to 31363F
            transcriptTab.style.backgroundColor = '#FF0000'; // Change background color to E14F30
        };
        // Adjust width and display of the summaryTab
        summaryTab.style.cssText = 'width: 20%; float: left; background-color: #141010; color: #ffffff; padding: 8px 12px; margin-right: 2px; border:none;  border-top-right-radius: 10px;';
        header.appendChild(summaryTab);

        // Transcript tab
        const transcriptTab = document.createElement('button');
        transcriptTab.textContent = 'Transcript';
        transcriptTab.classList.add('tab-button');
        transcriptTab.dataset.target = 'transcript-content';
        transcriptTab.onclick = function () {
            switchTab(transcriptContainer, transcriptTab);
            transcriptTab.style.backgroundColor = '#141010'; // Change background color to 31363F
            summaryTab.style.backgroundColor = '#FF0000'; // Change background color to E14F30
        };
        // Adjust width and display of the transcriptTab
        transcriptTab.style.cssText = 'width: 20%; float: left; top:0; background-color: #FF0000; color: #ffffff; padding: 8px 12px; margin-right: auto; border: none; border-top-left-radius: 10px;';
        header.appendChild(transcriptTab);
;

        const infoButton = document.createElement('button');
        infoButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
        <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
        </svg>`;
        infoButton.style.cssText = 'border: none; background: transparent; cursor: pointer; font-size: 16px; padding-right: 2x; margin-left: auto;';

        const tooltip = document.createElement('span');
        tooltip.textContent = 'This summary has been generated automatically and may not accurately reflect the context or details of the original text. Please verify its validity before relying on it for any important work or decision-making.';
        tooltip.style.cssText = `
        visibility: hidden;
        width: 200px;
        background-color: #333;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px;
        position: absolute;
        z-index: 1;
        top: calc(100% + 5px);
        left: 50%;
        transform: translateX(-50%);
        opacity: 0;
        transition: opacity 0.3s;
        `;

        infoButton.appendChild(tooltip);
        header.appendChild(infoButton);

        infoButton.addEventListener('mouseenter', () => {
        tooltip.style.visibility = 'visible';
        tooltip.style.opacity = '1';
        });

        infoButton.addEventListener('mouseleave', () => {
        tooltip.style.visibility = 'hidden';
        tooltip.style.opacity = '0';
        });

        const copyButton = document.createElement('button');
        copyButton.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1z"/>
            </svg>
        `;
        copyButton.title = 'Copy';
        copyButton.style.cssText = 'background: #FF0000; border:none; cursor: pointer; font-size: 16px; font-weight: bold; transition: background 0.3s; padding: 5px;';
        copyButton.onclick = function () {
            const activeTab = transcriptContainer.querySelector('.active-tab');
            const targetContentId = activeTab.dataset.target;
            const targetContent = document.getElementById(targetContentId);
            const range = document.createRange();
            range.selectNode(targetContent);
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
            document.execCommand('copy');
            selection.removeAllRanges();

            copyButton.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-square" viewBox="0 0 16 16">
                <path d="M3 14.5A1.5 1.5 0 0 1 1.5 13V3A1.5 1.5 0 0 1 3 1.5h8a.5.5 0 0 1 0 1H3a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h10a.5.5 0 0 0 .5-.5V8a.5.5 0 0 1 1 0v5a1.5 1.5 0 0 1-1.5 1.5z"/>
                <path d="m8.354 10.354 7-7a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0"/>
            </svg>
                `;
            copyButton.style.background = '#FF0000';
            setTimeout(() => {
                copyButton.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1z"/>
            </svg>
        `;
                copyButton.style.background = '#FF0000';
            }, 300);
        };
        header.appendChild(copyButton);

        // Close button in the header
        const closeButton = document.createElement('button');
        closeButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
        <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z"/>
      </svg>`;
        closeButton.style.cssText = 'border: none; background: transparent; cursor: pointer; font-size: 16px; padding-right: 10px;';
        closeButton.onclick = function () {
            transcriptContainer.style.opacity = '0';
            transcriptContainer.style.transform = 'translateY(20px)';
            setTimeout(() => transcriptContainer.remove(), 300);
        };
        closeButton.title = 'Close';

        header.appendChild(closeButton);


        transcriptContainer.appendChild(header);


        // Summary content
        const summaryContent = document.createElement('div');
        summaryContent.id = 'summary-content';
        summaryContent.className = 'tab-content';
        summaryContent.style.display = 'block';
        summaryContent.style.overflowY = 'auto';
        summaryContent.style.height = '85%'; // Adjust height
        summaryContent.style.fontSize = '14px';
        summaryContent.style.lineHeight = '1.5';
        summaryContent.style.color = '#333';
        summaryContent.textContent = transcriptData.summary;
        transcriptContainer.appendChild(summaryContent);

        // Transcript content
        const transcriptContent = document.createElement('div');
        transcriptContent.id = 'transcript-content';
        transcriptContent.className = 'tab-content';
        transcriptContent.style.display = 'none';
        transcriptContent.style.overflowY = 'auto';
        transcriptContent.style.height = '85%'; // Adjust height
        transcriptContent.style.fontSize = '14px';
        transcriptContent.style.lineHeight = '1.5';
        transcriptContent.style.color = '#333';
        transcriptContent.textContent = transcriptData.transcript;
        transcriptContainer.appendChild(transcriptContent);

        // Footer div
        const footer = document.createElement('div');
        footer.style.cssText = `
            position: absolute; bottom: 0; left: 0; width: 100%;
            height: 30px; padding: 5px; border-top: 1px solid; 
            display: flex; justify-content: center;
            align-items: center; background-color: #FF0000;
        `;

        // Download button in the footer
        const downloadButton = document.createElement('button');
        downloadButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-file-earmark-arrow-down-fill" viewBox="0 0 16 16">
        <path d="M9.293 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.707A1 1 0 0 0 13.707 4L10 .293A1 1 0 0 0 9.293 0M9.5 3.5v-2l3 3h-2a1 1 0 0 1-1-1m-1 4v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 11.293V7.5a.5.5 0 0 1 1 0"/>
      </svg>`;
      downloadButton.style.cssText = 'border: none; background: transparent; cursor: pointer; font-size: 16px; transition: background 0.3s;';
      downloadButton.title = 'Download';
      downloadButton.onclick = function () {
          const activeTab = transcriptContainer.querySelector('.active-tab');
          const targetContentId = activeTab.dataset.target;
          const targetContent = document.getElementById(targetContentId);
          const text = targetContent.textContent;
          const blob = new Blob([text], { type: 'text/plain' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          
          // Set the download filename based on whether it's a summary or transcript
          if (targetContentId === 'summary-content') {
              a.download = 'summary.txt';
          } else if (targetContentId === 'transcript-content') {
              a.download = 'transcript.txt';
          } else {
              a.download = 'file.txt';
          }
          
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
      
          downloadButton.style.background = '#cccccc';
          setTimeout(() => {
              downloadButton.style.background = 'transparent';
          }, 300);
      };
      
        footer.appendChild(downloadButton);

        transcriptContainer.appendChild(footer);

        document.body.appendChild(transcriptContainer);
    }
}

chrome.runtime.onMessage.addListener((message) => {
    if (message.transcript) {
        displayTranscript(message.transcript);
    } else if (message.error) {
        console.error('Error fetching transcript:', message.error);
    }
});

// Check for the YouTube player controls and add the button
const checkControlsAvailable = setInterval(() => {
    if (document.querySelector('.ytp-right-controls')) {
        addButton();
        clearInterval(checkControlsAvailable);
    }
}, 1000);
