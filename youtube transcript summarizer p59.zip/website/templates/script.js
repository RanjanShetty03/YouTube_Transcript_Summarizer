function submitYoutubeLink(link) {
    // AJAX call to Flask backend to handle the form submission
    $.ajax({
      url: '/submit_youtube_link',
      method: 'POST',
      data: { youtube_link: link },
      success: function(response) {
        // Display the transcript output
        $('#transcript-output').val(response.transcript);
        $('.output-text').show();
      },
      error: function(error) {
        console.error('Error:', error);
      }
    });
  }

function copyText() {
    var text = document.getElementById('output-text').innerText;
    navigator.clipboard.writeText(text)
        .then(() => alert('Text copied successfully'))
        .catch(err => console.error('Error in copying text: ', err));
}
